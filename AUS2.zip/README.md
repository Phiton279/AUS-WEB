# Aplikasi Toko Online dengan CodeIgniter
Repository ini berisi source code video tutorial cara membuat aplikasi toko online dengan framework PHP, CodeIgniter. Video tutorialnya dapat dibuka melalui halaman web http://kursus-php.com/video-tutorial/toko-online-codeigniter
